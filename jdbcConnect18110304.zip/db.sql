DROP SCHEMA IF EXISTS book_manager;
create schema book_manager;
use book_manager;

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
	`book_id` BIGINT AUTO_INCREMENT,
	`book_name` NVARCHAR(50) NOT NULL,
	`book_quantity` INT NOT NULL,
	`book_image_path` LONGTEXT NOT NULL,
    
    PRIMARY KEY(`book_id`)
) ENGINE = InnoDB;

insert into `book`(`book_name`, `book_quantity`, `book_image_path`)
values 
	(N'The clean Coder', 5, N'.\\images\\1.jpg'),
	(N'Head first javascript', 10, N'.\\images\\2.jpg'),
    (N'Head first C', 7, N'.\\images\\3.jpg'),
    (N'Head first Java', 4, N'.\\images\\4.jpg');