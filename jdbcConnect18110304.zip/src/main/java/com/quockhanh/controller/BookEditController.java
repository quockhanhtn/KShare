package com.quockhanh.controller;

import com.quockhanh.model.BookDAO;
import com.quockhanh.model.BookDTO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(urlPatterns = {"/book-edit"})
public class BookEditController extends HttpServlet {
   @Override
   protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

      Long bookId = Long.valueOf(0);
      String strBookId = req.getParameter("bookId");
      try {
         bookId = Long.parseLong(strBookId);
      } catch (NumberFormatException e) {
         bookId = Long.valueOf(0);
      }

      if (bookId == 0) {
         resp.sendRedirect(req.getContextPath() + "/book");
      }
      else {
         BookDTO bookUpdate = BookDAO.getInstance().getById(bookId);
         if (bookUpdate == null) {
            resp.sendRedirect(req.getContextPath() + "/book");
         }
         else {
            req.setAttribute("bookUpdate", bookUpdate);
            RequestDispatcher reqDispatcher = req.getRequestDispatcher("/book-edit.jsp");
            reqDispatcher.forward(req, resp);
         }
      }
   }

   @Override
   protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      super.doPost(req, resp);
   }
}