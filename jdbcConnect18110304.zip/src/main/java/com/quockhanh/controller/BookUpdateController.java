package com.quockhanh.controller;

import com.quockhanh.model.BookDAO;
import com.quockhanh.model.BookDTO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = {"/book-update"})
public class BookUpdateController extends HttpServlet {
   void goToErrorPage(HttpServletRequest req, HttpServletResponse resp) {
      try {
         req.setAttribute("errorMessage", "Error while update");
         getServletContext().getRequestDispatcher("/error.jsp").forward(req, resp);
      } catch (ServletException | IOException e) {
         e.printStackTrace();
      }
   }

   @Override
   protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      String strBookId, strbookQuantity, bookName = null, bookImagePath = null;
      Long bookId = Long.valueOf(0);
      Integer bookQuantity = 0;
      try {
         strBookId = req.getParameter("book-id");
         bookName = req.getParameter("book-name");
         strbookQuantity = req.getParameter("book-quantity");
         bookImagePath = req.getParameter("book-image_path");

         bookId = Long.parseLong(strBookId);
         bookQuantity = Integer.parseInt(strbookQuantity);
      } catch (Exception e) {
         goToErrorPage(req, resp);
      }

      BookDTO dto = BookDAO.getInstance().getById(bookId);
      if (dto != null) {

         dto.setBookName(bookName != null ? bookName : "");
         dto.setBookQuantity(bookQuantity);
         dto.setBookImagePath(bookImagePath != null ? bookImagePath : "");

         if (BookDAO.getInstance().update(dto) > 0) {
            resp.sendRedirect(req.getContextPath() + "/book");
         }
         else {
            goToErrorPage(req, resp);
         }
      }
      else {
         goToErrorPage(req, resp);
      }
   }

   @Override
   protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      doGet(req, resp);
   }
}