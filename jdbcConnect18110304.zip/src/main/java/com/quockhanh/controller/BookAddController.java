package com.quockhanh.controller;

import com.quockhanh.model.BookDAO;
import com.quockhanh.model.BookDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = {"/book-add"})
public class BookAddController extends HttpServlet {
   void goToErrorPage(HttpServletRequest req, HttpServletResponse resp) {
      try {
         req.setAttribute("errorMessage", "Error while add new book");
         getServletContext().getRequestDispatcher("/error.jsp").forward(req, resp);
      } catch (ServletException | IOException e) {
         e.printStackTrace();
      }
   }
   @Override
   protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      String strBookId, strbookQuantity, bookName = null, bookImagePath = null;

      Integer bookQuantity = 0;
      try {
         bookName = req.getParameter("book-name");
         strbookQuantity = req.getParameter("book-quantity");
         bookImagePath = req.getParameter("book-image_path");

         bookQuantity = Integer.parseInt(strbookQuantity);
      } catch (Exception e) {
         goToErrorPage(req, resp);
      }

      BookDTO dto = new BookDTO(0L, bookName, bookQuantity, bookImagePath);
      Long newBookId = BookDAO.getInstance().insert(dto);
      if (newBookId != null || newBookId != 0) {
         resp.sendRedirect(req.getContextPath() + "/book");
      }
      else {
         goToErrorPage(req, resp);
      }
   }

   @Override
   protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      doGet(req, resp);
   }
}
