package com.quockhanh.model;

import java.sql.ResultSet;
import java.sql.SQLException;

public class BookDTO {
   Long bookId;
   String bookName;
   Integer bookQuantity;
   String bookImagePath;

   public Long getBookId() {
      return bookId;
   }

   public void setBookId(Long bookId) {
      this.bookId = bookId;
   }

   public String getBookName() {
      return bookName;
   }

   public void setBookName(String bookName) {
      this.bookName = bookName;
   }

   public Integer getBookQuantity() {
      return bookQuantity;
   }

   public void setBookQuantity(Integer bookQuantity) {
      this.bookQuantity = bookQuantity;
   }

   public String getBookImagePath() {
      return bookImagePath;
   }

   public void setBookImagePath(String bookImagePath) {
      this.bookImagePath = bookImagePath;
   }

   public BookDTO(Long bookId, String bookName, Integer bookQuantity, String bookImagePath) {
      this.bookId = bookId;
      this.bookName = bookName;
      this.bookQuantity = bookQuantity;
      this.bookImagePath = bookImagePath;
   }

   public BookDTO (ResultSet resultSet) {
      try {
         bookId = resultSet.getLong("book_id");
         bookName = resultSet.getString("book_name");
         bookQuantity = resultSet.getInt("book_quantity");
         bookImagePath = resultSet.getString("book_image_path");
      } catch (SQLException exception) {
         exception.printStackTrace();
      }
   }
}
