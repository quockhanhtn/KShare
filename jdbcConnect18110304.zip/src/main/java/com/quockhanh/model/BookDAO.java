package com.quockhanh.model;

import com.quockhanh.utils.DatabaseUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BookDAO {
   public ArrayList<BookDTO> gets() {
      ArrayList<BookDTO> result = new ArrayList<>();

      String query = "SELECT * FROM BOOK;";
      ResultSet resultSet = DatabaseUtils.executeQuery(query, null);

      if (resultSet == null) {
         return result;
      }

      try {
         while (resultSet.next()) {
            BookDTO bookDTO = new BookDTO(resultSet);
            result.add(bookDTO);
         }
      } catch (SQLException exception) {
         exception.printStackTrace();
      }

      return result;
   }

   public BookDTO getById(Long id) {
      String sql = "SELECT * FROM BOOK WHERE BOOK_ID = " + id + ";";
      ResultSet resultSet = DatabaseUtils.executeQuery(sql, null);

      try {
         if (resultSet != null && resultSet.next()) {
            return new BookDTO(resultSet);
         }
      } catch (SQLException exception) {
         exception.printStackTrace();
      }
      return null;
   }

   public Long insert(BookDTO dto) {
      String sql = "INSERT INTO `BOOK`(`BOOK_NAME`, `BOOK_QUANTITY`, `BOOK_IMAGE_PATH`) VALUES (?, ?, ?);";
      List<Object> parameters = Arrays.asList(
              dto.getBookName(),
              dto.getBookQuantity(),
              dto.getBookImagePath()
      );
      return (Long) DatabaseUtils.executeUpdateAutoIncrement(sql, parameters);
   }

   public int update(BookDTO dto) {
      String sql = "UPDATE BOOK SET BOOK_NAME = ?, BOOK_QUANTITY = ?, BOOK_IMAGE_PATH = ? WHERE BOOK_ID = ?";
      List<Object> parameters = Arrays.asList(
              dto.getBookName(),
              dto.getBookQuantity(),
              dto.getBookImagePath(),
              dto.getBookId()
      );
      return DatabaseUtils.executeUpdate(sql, parameters);
   }

   public int delete(Long id) {
      String sql = "DELETE FROM BOOK WHERE BOOK_ID = ?";
      List<Object> parameters = Collections.singletonList(id);
      return DatabaseUtils.executeUpdate(sql, parameters);
   }

   private static BookDAO instance = null;

   private BookDAO() {
   }

   public static BookDAO getInstance() {
      if (instance == null) {
         instance = new BookDAO();
      }
      return instance;
   }
}
